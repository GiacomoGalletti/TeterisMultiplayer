package BlockWar.Logic;


public enum Directions {
    UP,
    RIGHT,
    DOWN,
    LEFT
}